
package com.example.poolai

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var windowManager: WindowManager
    private var floatingView: LinearLayout? = null
    private var minimized = false

    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(30, 40, 30, 30)
            setBackgroundColor(Color.rgb(245, 247, 248))
        }

        val title = TextView(this).apply {
            text = "POOL AI ANALYZER"
            textSize = 25f
            setTextColor(Color.BLACK)
            gravity = Gravity.CENTER
        }

        val description = TextView(this).apply {
            text = "Assistente de análise para 8 Ball Pool"
            textSize = 16f
            setPadding(0, 25, 0, 25)
            setTextColor(Color.DKGRAY)
        }

        val activate = Button(this).apply {
            text = "ATIVAR JANELA FLUTUANTE"
            setOnClickListener {
                if (Settings.canDrawOverlays(this@MainActivity)) {
                    showFloatingWindow()
                } else {
                    val intent = Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")
                    )
                    startActivity(intent)
                }
            }
        }

        status = TextView(this).apply {
            text = "Aguardando ativação."
            textSize = 16f
            setPadding(0, 25, 0, 0)
            setTextColor(Color.BLACK)
        }

        root.addView(title)
        root.addView(description)
        root.addView(activate)
        root.addView(status)

        setContentView(root)
    }

    override fun onResume() {
        super.onResume()

        if (::status.isInitialized &&
            Settings.canDrawOverlays(this) &&
            floatingView == null
        ) {
            status.text = "Permissão concedida. Toque em ativar."
        }
    }

    private fun showFloatingWindow() {

        if (floatingView != null) return

        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(
                this,
                "Permita a sobreposição nas configurações.",
                Toast.LENGTH_LONG
            ).show()
            return
        }

        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(12, 10, 12, 10)
            setBackgroundColor(Color.rgb(25, 45, 55))
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        val heading = TextView(this).apply {
            text = "POOL AI"
            textSize = 17f
            setTextColor(Color.WHITE)
            setPadding(8, 8, 20, 8)
        }

        val minimize = Button(this).apply {
            text = "−"
            textSize = 18f
        }

        val close = Button(this).apply {
            text = "X"
        }

        header.addView(
            heading,
            LinearLayout.LayoutParams(0, -2, 1f)
        )
        header.addView(minimize)
        header.addView(close)

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(10, 15, 10, 10)
        }

        val message = TextView(this).apply {
            text = "Aguardando captura da mesa..."
            textSize = 14f
            setTextColor(Color.WHITE)
        }

        content.addView(message)

        panel.addView(header)
        panel.addView(content)

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 30
            y = 180
        }

        floatingView = panel

        try {
            windowManager.addView(panel, params)
        } catch (e: Exception) {
            floatingView = null
            status.text = "Erro ao abrir janela: ${e.message}"
            return
        }

        minimize.setOnClickListener {
            minimized = !minimized
            content.visibility =
                if (minimized) View.GONE else View.VISIBLE
            minimize.text = if (minimized) "+" else "−"
        }

        close.setOnClickListener {
            removeFloatingWindow()
        }

        header.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    true
                }

                MotionEvent.ACTION_MOVE -> {
                    val newX = event.rawX.toInt() - panel.width / 2
                    val newY = event.rawY.toInt() - header.height / 2

                    params.x = newX
                    params.y = newY

                    try {
                        windowManager.updateViewLayout(panel, params)
                    } catch (_: Exception) {
                    }
                    true
                }

                else -> true
            }
        }

        status.text = "Janela flutuante ativada!"
    }

    private fun removeFloatingWindow() {
        floatingView?.let {
            try {
                windowManager.removeView(it)
            } catch (_: Exception) {
            }
        }

        floatingView = null
        minimized = false
        status.text = "Janela flutuante fechada."
    }

    override fun onDestroy() {
        removeFloatingWindow()
        super.onDestroy()
    }
}

