# Pool AI — Android starter (v0.1)

Um protótipo inicial em Kotlin para Android Studio. Ele permite importar e visualizar uma captura de tela do jogo.

## O que já funciona
- Projeto Android Studio básico.
- Seleção de uma imagem pelo seletor de arquivos do Android.
- Exibição da captura e dimensões da imagem.

## O que ainda NÃO funciona
- Não identifica automaticamente bolas, cores, caçapas ou obstáculos.
- Não calcula tacadas confiáveis.
- Não controla o jogo nem joga sozinho.
- Não foi compilado/testado neste ambiente; abra no Android Studio para sincronizar e compilar.

## Como abrir
1. Instale o Android Studio em um computador.
2. Extraia o ZIP.
3. No Android Studio, escolha **Open** e selecione a pasta `PoolAI_Android_Starter`.
4. Aguarde o Gradle sincronizar.
5. Execute em um celular Android ou emulador.

## Próximas etapas técnicas
1. Delimitar a mesa e corrigir perspectiva.
2. Detectar centros e raios das bolas com OpenCV ou um modelo treinado.
3. Classificar bola branca, lisas, listradas e bola 8.
4. Detectar caçapas e obstáculos.
5. Implementar simulação de colisões e pontuação de tacadas.
6. Manter a primeira versão como analisador/treinador; não automatizar partidas competitivas online.

## Observação
O layout e a API Android usam Kotlin. Para a próxima etapa de visão computacional, podemos integrar OpenCV e testar com capturas reais fornecidas por você.

## Gerar APK sem instalar Android Studio no celular
Este projeto inclui um workflow do GitHub Actions (`.github/workflows/build-apk.yml`) para compilar o APK na nuvem.
1. No computador, crie um repositório no GitHub e envie todos os arquivos desta pasta.
2. Abra a aba **Actions** do repositório.
3. Execute **Build Android APK** (ou aguarde a compilação após enviar para a branch `main`).
4. Abra a execução concluída e baixe o artefato **PoolAI-debug-apk**.
5. Extraia o artefato e instale `app-debug.apk` no Android, permitindo instalação dessa fonte quando o sistema pedir.

O APK resultante é de depuração e não é publicado na Play Store. A compilação pode revelar erros que precisam ser corrigidos. O assistente não executou essa compilação neste ambiente.
